package game;

import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;

public final class Game extends JFrame implements ActionListener {

    private JButton exitBtn, replayBtn;
    private JLabel scoreLbl;
    private int contador = 0, btncheck0, btncheck1, btnnum1, btnnum0, maximo = 0;
    public int aciertos = 0, clicks = 0, total_max;
    private int[] numeros = new int[16];
    public String[][] topscores;
    public String usrname, nombremax;
    ImageIcon logo[] = new ImageIcon[8];
    private JButton[] gameBtn = new JButton[16];

    public int getbtnnum1() {
        return btnnum1;
    }

    public int getbtnnum0() {
        return btnnum0;
    }

    public int getbtncheck0() {
        return btncheck0;
    }

    public int getbtncheck1() {
        return btncheck1;
    }

    public void setgameBtn(int n) {
        gameBtn[n].setIcon(null);
    }

    public void setcontador(int n) {
        contador = n;
    }

    public Game() {
        name();
        readmaxscore();
        initPictureIcons();
        shuffle();
        init();
        panel();
        setTitle("MemoryGame");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 500);
        setVisible(true);
    }
    
    public void name() {
        usrname = JOptionPane.showInputDialog(null, "Nombre de jugador");
    }
    
    public void readmaxscore() {
        total_max = manejador_archivos.contarElementos("topscores.txt");
        topscores = new String [total_max][2];
        manejador_archivos.cargar(topscores, "topscores.txt");
        for (int i = 0; i < total_max; i++) {
            if(maximo < Integer.valueOf(topscores[i][1])) {
                maximo = Integer.valueOf(topscores[i][1]);
                nombremax = topscores[i][0];
            }
        }
    }
    
    public void initPictureIcons() {
        for (int i = 0; i < 8; i++) {
            logo[i] = new ImageIcon(getClass().getResource(Integer.toString(i) + ".png"));
        }
    }

    public void init() {
        for (int i = 0; i < gameBtn.length; i++) {
            gameBtn[i] = new JButton();
            gameBtn[i].setFont(new Font("Serif", Font.BOLD, 28));
            //gameBtn[i].setIcon(logo[numeros[i]]);
            gameBtn[i].addActionListener(this);
        }
        exitBtn = new JButton("Exit");
        exitBtn.addActionListener(this);
        replayBtn = new JButton("Replay");
        replayBtn.addActionListener(this);
        scoreLbl = new JLabel("Jugador: " + usrname + "        Puntuación maxima: " + nombremax + " " + maximo);
    }

    public void shuffle() {
        int num, contador, estado = 0;
        for (int i = 0; i < 16; i++) {
            numeros[i] = -1;
        }

        for (int i = 0; i < 16; i++) {
            do {
                num = (int) (Math.random() * 8);
                if (numeros[i] == -1) {
                    contador = 0;
                    for (int j = 0; j < 16; j++) {
                        if (numeros[j] == num) {
                            contador++;
                        }
                    }
                    if (contador < 2) {
                        numeros[i] = num;
                        estado = 1;
                    } else {
                        estado = 2;
                    }
                }
            } while (estado != 1);
        }
        for (int i = 0; i < 16; i++) {
            System.out.print(numeros[i] + " ");
        }
    }

    public void panel() {
        Panel gamePnl = new Panel();
        gamePnl.setLayout(new GridLayout(4, 4));
        for (int i = 0; i < gameBtn.length; i++) {
            gamePnl.add(gameBtn[i]);
        }

        Panel buttonPnl = new Panel();
        Panel scorePnl = new Panel();
        scorePnl.add(scoreLbl);
        buttonPnl.add(replayBtn);
        buttonPnl.add(exitBtn);
        buttonPnl.setLayout(new GridLayout(1, 0));
        
        add(scorePnl, BorderLayout.NORTH);
        add(gamePnl, BorderLayout.CENTER);
        add(buttonPnl, BorderLayout.SOUTH);

    }
    
    public static void win(int a) {
        JOptionPane.showMessageDialog(null, "Ganaste! puntuacion: " + a);
    }
    public static void grabar(int contador_sco, String[][] array_sco, String usrnm, int clks) {
        System.out.print("grabando");
        FileWriter fichero = null;
        try {
            fichero = new FileWriter("topscores.txt");
            PrintWriter pw = new PrintWriter(fichero);
            int existe = 0, posicion = 0;
            for (int i = 0; i < contador_sco; i++) {
                if(array_sco[i][0].equals(usrnm)) {
                    existe = 1;
                    posicion = i;
                }
            }
            for (int i = 0; i < contador_sco; i++) {
                pw.print(array_sco[i][0] + "  " + array_sco[i][1] + "\n");
            }
            if(existe == 1) {
                if(Integer.valueOf(array_sco[posicion][1]) > clks) {
                    array_sco[posicion][1] = Integer.toString(clks);
                }
            } else {
                pw.print(usrnm + "  " + Integer.toString(clks));                
            }
            
        } catch (IOException ex) {
            System.out.println("Error al guardar en el archivo" + ex);
        } finally {
            try {
                fichero.close();
            } catch (IOException ex) {
                System.out.println("Error al cerrar el archivo" + ex);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (exitBtn == e.getSource()) {
            System.exit(0);
        }

        if (replayBtn == e.getSource()) {
            for (int i = 0; i < gameBtn.length; i++) {
                gameBtn[i].setIcon(null);
            }
            contador = 0;
        }

        for (int i = 0; i < gameBtn.length; i++) {
            if (gameBtn[i] == e.getSource()) {
                gameBtn[i].setIcon(logo[numeros[i]]);
                contador++;
                clicks++;
                if (contador == 1) {
                    btncheck0 = numeros[i];
                    btnnum0 = i;
                }
                if (contador == 2) {
                    btncheck1 = numeros[i];
                    btnnum1 = i;
                    contador = 0;
                    Hilo hilito = new Hilo(this);
                    hilito.start();
                }
            }
        }
    }

    public static void main(String[] args) {
        Game game = new Game();
    }
}
