package game;

import java.io.*;

public class manejador_archivos {
    public static int contarElementos(String Archivo){
		int contador=0; 
		File f;
		FileReader fr;
                BufferedReader br;
                String linea;
        try{
        	f = new File(Archivo);
        	fr = new FileReader(f);
        	br = new BufferedReader(fr);
        	
        	while((linea = br.readLine())!=null){
    			contador++;
        	}

        }catch (Exception e) {
        	
		}
		return contador;
	}
	
	public static void cargar(String [][]Clientes, String Archivo){
		int contador=0;
		File f;
		FileReader fr = null;
                BufferedReader br = null;
                String linea;
        try{
            f = new File(Archivo);
            fr = new FileReader(f);
            br = new BufferedReader(fr);

            while((linea = br.readLine())!=null){
                    Clientes[contador]=linea.split("  ");    		
                    contador++;
            }

        }catch (Exception e) {
               System.out.println(e.getMessage());
            } finally {
            try {
                if(fr != null) {
                    fr.close();
                }
                if (br != null) {
                    br.close();
                }
            } catch (IOException ex) {
                System.out.print("Error al cerrar el archivo" + ex);
            }
            }	
	}		
	

	public static void PutFileLine(String url, String linea) throws IOException{
		FileWriter f0 = null;
		PrintWriter pw = null;
		f0 = new FileWriter(url, true);
		pw = new PrintWriter(f0); 
		pw.println(linea);
                pw.close();
                f0.close();
		
	}
}