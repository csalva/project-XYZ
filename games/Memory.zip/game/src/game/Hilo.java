package game;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Daniel
 */
class Hilo extends Thread {

    Game fil;

    Hilo(JFrame joc) {
        fil = (Game) joc;

    }

    @Override
    public void run() {
        try {
            int num1 = fil.getbtnnum1();
            int num0 = fil.getbtnnum0();
            Thread.sleep(1000);
            if (fil.getbtncheck0() != fil.getbtncheck1()) {
                fil.setgameBtn(num1);
                fil.setgameBtn(num0);
            } else {
                fil.aciertos++;
                if(fil.aciertos == 8) {
                    Game.win(fil.clicks);
                    Game.grabar(fil.total_max, fil.topscores, fil.usrname, fil.clicks);
                }
            }
            fil.setcontador(0);
        } catch (InterruptedException ex) {
            System.out.println("Error en el thread " + ex);
        }
    }
}
